"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved

Author: Dejiao Zhang (dejiaoz@amazon.com)
Date: 02/26/2021
"""

import torch
import numpy as np
from utils.metric import Confusion
from sklearn.cluster import KMeans
from sklearn.cluster import AgglomerativeClustering
from sklearn.cluster import Birch
from sklearn.cluster import AffinityPropagation
from sklearn.cluster import MeanShift
import sklearn.cluster as sc
from sklearn.mixture import GaussianMixture
def get_mean_embeddings(bert, input_ids, attention_mask):
    bert_output = bert.forward(input_ids=input_ids, attention_mask=attention_mask)
    attention_mask = attention_mask.unsqueeze(-1)
    mean_output = torch.sum(bert_output[0] * attention_mask, dim=1) / torch.sum(attention_mask, dim=1)
    mean_output=  bert_output[0][:,0,:]
    return mean_output


def get_batch_token(tokenizer, text, max_length):
    token_feat = tokenizer.batch_encode_plus(
        text,
        max_length=max_length,
        return_tensors='pt',
        padding='max_length',
        truncation=True
    )
    return token_feat


def get_kmeans_centers(bert, tokenizer, train_loader, num_classes, max_length):
    for i, batch in enumerate(train_loader):
        print("get kmeans centers : {} ".format(i))
        label = batch['label']

        # 原dataloader
        # text, label = batch['text'], batch['label']
        # tokenized_features = get_batch_token(tokenizer, text, max_length)
        # corpus_embeddings0 = get_mean_embeddings(bert, **tokenized_features)
        # 新dataloader
        corpus_embeddings0 = get_mean_embeddings(bert, batch['input_id'][:, 0, :], batch['attention_mask'][:, 0, :])

        if i == 0:
            all_labels = label
            all_embeddings = corpus_embeddings0.detach().numpy()
        else:
            all_labels = torch.cat((all_labels, label), dim=0)
            all_embeddings = np.concatenate((all_embeddings, corpus_embeddings0.detach().numpy()), axis=0)
    print("get kmeans centers : OK!")

    # Perform KMeans clustering
    confusion = Confusion(num_classes)
    clustering_model = KMeans(n_clusters=num_classes)
    # clustering_model = AgglomerativeClustering(n_clusters=num_classes, linkage="ward")
    # clustering_model=AffinityPropagation(damping=0.5, max_iter=5, convergence_iter=30,
    #                      preference=-50)
    # clustering_model = GaussianMixture(n_components=num_classes)
    # clustering_model=Birch(n_clusters=num_classes,threshold=0.2)
    # bw = sc.estimate_bandwidth(all_embeddings, n_samples=len(all_embeddings), quantile=0.1)
    # clustering_model = sc.MeanShift(bandwidth=bw, bin_seeding=True)
    # model = AffinityPropagation(damping=0.5, max_iter=500, convergence_iter=30,
    #                             preference=-50)


    # clustering_model.fit(all_embeddings)
    # cluster_centers_indices =  clustering_model.cluster_centers_indices_
    # cluster_assignment = clustering_model.labels_
    cluster_assignment =clustering_model.fit_predict(all_embeddings)
    true_labels = all_labels
    pred_labels = torch.tensor(cluster_assignment)
    print("all_embeddings:{}, true_labels:{}, pred_labels:{}".format(all_embeddings.shape, len(true_labels),
                                                                     len(pred_labels)))

    confusion.add(pred_labels, true_labels)
    confusion.optimal_assignment(num_classes)
    print("Iterations:{}, Clustering ACC:{:.3f}, centers:{}".format(clustering_model.n_iter_, confusion.acc(),
                                                                    clustering_model.cluster_centers_.shape))
    # print(" Clustering ACC:{:.3f}, centers:{}".format( confusion.acc(),
    #                                                                 clustering_model.means_))
    return   clustering_model.cluster_centers_
